local imports = {
    "android.*",
    "android.app.*",
    "android.content.*",
    "android.graphics.*",
    "android.graphics.drawable.*",
    "android.os.*",
    "android.view.*",
    "android.widget.*",
    "android.ext.*",
    "android.view.animation.*",
    "android.animation.ObjectAnimator",
    "com.ldoublem.loadingviewlib.view.*",
    "com.ldoublem.loadingviewlib.view.base.LVBase",
    "com.ldoublem.loadingviewlib.LVCircularCD",
    "com.ldoublem.loadingviewlib.view.LVCircularRing",
    "com.ldoublem.loadingviewlib.view.LVBlock",
    "com.romainpiel.shimmer.*",
    "java.io.File",
    "java.lang.*",
    "java.util.*"
}

for _, lib in ipairs(imports) do
    import(lib)
end

Gravity = luajava.bindClass("android.view.Gravity")
toast.setGravity(Gravity.BOTTOM)
toast.setMode(1)

ButtonAlert = function(button)
    gg.alert("Please Follow The Rules", "Got it")
end

On = function(button)
    On_Tips = Name .. " Activated successfully!"
    toast.success(On_Tips,1500)
end

Off = function(button)
    Off_Tips = Name .. " Deactivated successfully!"
    toast.error(Off_Tips,1500)
    gg.clearList()
    gg.clearResults()
end

local buttonStates = {}
local function Ui_Test(button)
    if buttonStates[button] == nil then
        buttonStates[button] = false
    end
    if buttonStates[button] == false then
        buttonStates[button] = true
        On(button)
      else
        buttonStates[button] = false
        Off(button)
    end
end

local Point = HotPoint.instance
local Point_posX = FloatPanel.getDeclaredField("x").setAccessible(true)
local Point_posY = FloatPanel.getDeclaredField("y").setAccessible(true)
local Point_sizePx = HotPoint.getDeclaredMethod("getSizePx").setAccessible(true).invoke(Point).."px"
local Point_alpha = FloatPanel.getDeclaredMethod("getLayoutAlpha").setAccessible(true).invoke(Point)
local Point_mVanishingTime = HotPoint.getDeclaredMethod("getVanishingTime").setAccessible(true).invoke(Point)
gg.setVisible(false)
toast.hint("ʙɪʜᴀʀɪ ᴍᴏᴅꜱ Has Entered Hidden Mode..!", 1500)
Point.hide()
toast.success("ʙɪʜᴀʀɪ ᴍᴏᴅꜱ Has Been Activated..!", 1500)

local context = activity
local window = context.getSystemService("window")
local mObjectAnimator, dObjectAnimator

local function sparkle_animation(view)
    if not mObjectAnimator then
        mObjectAnimator = ObjectAnimator.ofFloat(view, "alpha", 0, Point_alpha)
        mObjectAnimator.setDuration(800)
        mObjectAnimator.setInterpolator(DecelerateInterpolator())
    end
end

local function zoom_animation(view)
    if not dObjectAnimator then
        dObjectAnimator = ObjectAnimator.ofFloat(view, "scaleX", 0, 1)
        dObjectAnimator.setDuration(600)
        dObjectAnimator.setInterpolator(DecelerateInterpolator())
    end
end

local function zoom_startanimation()
    if dObjectAnimator then
        dObjectAnimator.start()
    end
end

local function sparkle_startanimation()
    if mObjectAnimator then
        mObjectAnimator.start()
    end
end

local function getLayoutParams()
    local LayoutParams = WindowManager.LayoutParams
    local layoutParams = luajava.new(LayoutParams)
    layoutParams.type = (Build.VERSION.SDK_INT >= 26) and LayoutParams.TYPE_APPLICATION_OVERLAY or LayoutParams.TYPE_PHONE
    layoutParams.format = PixelFormat.RGBA_8888
    layoutParams.flags = LayoutParams.FLAG_NOT_FOCUSABLE
	layoutParams.gravity = Gravity.TOP | Gravity.LEFT
    layoutParams.width = LayoutParams.WRAP_CONTENT
    layoutParams.height = LayoutParams.WRAP_CONTENT
    return layoutParams
end

local function getShapeBackground(color, radius)
    local drawable = luajava.new(GradientDrawable)
    drawable.setShape(GradientDrawable.RECTANGLE)
    drawable.setColor(color)
    drawable.setCornerRadii({radius, radius, radius, radius, radius, radius, radius, radius})
    return drawable
end

local function iOSwitch(isChecked)
    local trackColor = isChecked and 0xEE4CD964 or 0xEEEEEEEE
    local thumbColor = isChecked and 0xFFFFFFFF or 0xFFBDBDBD
    local radius = 70
    local thumbRadius = 25
    local width = 55
    local height = 45
    local trackDrawable = luajava.new(GradientDrawable)
    trackDrawable.setShape(GradientDrawable.RECTANGLE)
    trackDrawable.setColor(trackColor)
    trackDrawable.setCornerRadius(radius)
    trackDrawable.setSize(width, height)
    local thumbDrawable = luajava.new(GradientDrawable)
    thumbDrawable.setShape(GradientDrawable.OVAL)
    thumbDrawable.setColor(thumbColor)
    thumbDrawable.setSize(thumbRadius * 2, thumbRadius * 2)
    local thumbX = isChecked and (width - thumbRadius * 2) or 0
    local thumbY = (height - thumbRadius * 2) / 2
    thumbDrawable.setBounds(thumbX, thumbY, thumbX + thumbRadius * 2, thumbY + thumbRadius * 2)
    return trackDrawable, thumbDrawable
end

function updateiOSwitch(switchView, isChecked)
    local trackDrawable, thumbDrawable = iOSwitch(isChecked)
    switchView.setTrackDrawable(trackDrawable)
    switchView.setThumbDrawable(thumbDrawable)
end

local log = function(text,color, size)
    local tmp = loadlayout {
        TextView,
        text = os.date("  %Y-%m-%d %H:%M:%S ") .. text,
        textSize = size or '10sp',
        textColor = color or "#FF303030",
        gravity = "center_vertical",
        layout_width = "wrap_content",
    }
    Runlog_list.addView(tmp)
    Runlog.fullScroll(View.FOCUS_DOWN)
end

function ExitText(id, defaultText, labelText)
    return {
        LinearLayout;
        layout_marginStart = "2.5dp";
        layout_marginEnd = "2.5dp";
        layout_height = "40dp";
        orientation = "vertical";
        layout_width = "fill";
        {
            TextView;
            text = labelText;
            textColor = "#FF303030";
        };
        {
            LinearLayout;
            layout_height = "fill";
            orientation = "horizontal";
            layout_width = "fill";
            layout_marginTop = "2.5dp";
            layout_marginBottom = "2.5dp";
            layout_marginStart = "2.5dp";
            layout_marginEnd = "2.5dp";
            {
                EditTextPath;
                id = id;
                text = defaultText;
                textColor = "#DDDDDDDD";
                layout_width = "100%w";
                inputType = "text";
                imeOptions = "actionDone";
            };
        };
    }
end

function ShimmerLayout1(id, text)
    return {
        ShimmerTextView;
        layout_width = "match_parent";
        layout_height = "match_parent";
        id = id;
        text = text;
        reflectionColor = "#EEEEEEEE";
        textColor = "#FF303030";
        textSize = "15sp";
        gravity = "center";
    }
end

function ShimmerLayout2(id, text, gravity, textSize, margin)
    return {
        ShimmerTextView;
        layout_centerVertical = "true";
        reflectionColor = "#EEEEEEEE";
        textColor = "#FF303030";
        layout_margin = margin or "5dp";
        textSize = textSize or "15sp";
        layout_height = "match_parent";
        layout_width = "match_parent";
        id = id;
        text = text;
        gravity = gravity;
    }
end

local function shimmerButton(id, text)
    return {
        ShimmerTextView;
        layout_width = "match_parent";
        layout_height = "match_parent";
        id = id;
        text = text;
        reflectionColor = "#EEEEEEEE";
        textColor = "#FF303030";
        textSize = "15sp";
        gravity = "center";
    }
end

local function ButtonLayout(id, text)
    return {
        LinearLayout;
        layout_width = "match_parent";
        layout_height = "37.5dp";
        layout_margin = "5dp";
        gravity = "center";
        shimmerButton(id, text),
    }
end

function AboutLayout(id1, text1, id2, text2)
    return {
        LinearLayout,
        layout_height = "wrap_content",
        orientation = "horizontal",
        layout_width = "match_parent",
        gravity = "center_vertical",
        {
            CircleImageView,
            layout_width = "37.5dp",
            layout_height = "37.5dp",
            id = id1,
            layout_margin = "5dp",
        },
        {
            ShimmerTextView,
            reflectionColor = "#FFFFFF00",
            textColor = "#EEEE0000",
            layout_margin = "5dp",
            textSize = "15sp",
            id = id1 .. "1",
            layout_height = "wrap_content",
            layout_width = "wrap_content",
            text = text1,
            gravity = "center",
        },
        {
            ShimmerTextView,
            reflectionColor = "#EEEEEEEE",
            textColor = "#FF303030",
            layout_margin = "5dp",
            textSize = "15sp",
            id = id1 .. "2",
            layout_height = "wrap_content",
            layout_width = "wrap_content",
            text = text2,
            gravity = "center|right",
        },
    }
end

page1 = {
    LinearLayout;
    layout_width="fill";
    layout_height="fill";
    {
        LinearLayout;
        layout_height="match_parent";
        layout_margin="5.0dp";
        layout_width="match_parent";
        {
            ScrollView;
            layout_height="match_parent";
            padding="0.0dp";
            layout_width="match_parent";
            VerticalScrollBarEnabled=true;
            {
                LinearLayout;
                background = getShapeBackground(0xCCCCCCCC,30);
                layout_height="match_parent";
                layout_width="match_parent";
                orientation="vertical";
                id="FuncLayout";
            };
        };
    };
}

page2 = {
    LinearLayout;
    layout_height = "fill";
    orientation = "vertical";
    layout_width = "fill";
    {
        LinearLayout;
        layout_marginTop = "5dp";
        layout_marginBottom = "5dp";
        layout_marginStart = "5dp";
        layout_marginEnd = "5dp";
        layout_height = "fill";
        orientation = "vertical";
        background = getShapeBackground(0xCCCCCCCC, 30);
        layout_width = "fill";
        {
            TextView;
            text = "⚠️ALERT⚠️:\nThis Is Fully Antiban Panel\nAfter Finished Your Game Please Clear Your Game Data";
            textColor = "#FF303030";
            layout_marginTop = "2.5dp";
            layout_marginBottom = "2.5dp";
            layout_marginEnd = "5dp";
            layout_marginStart = "5dp";
            layout_width = "wrap_content";
        };
        {
            TextView;
            text = "Notice 1";
            id = "Get_Zb_Data";
            background = getShapeBackground(0xFF303030, 30);
            layout_width = "match_parent";
            layout_marginTop = "2.5dp";
            layout_marginBottom = "2.5dp";
            layout_marginEnd = "5dp";
            layout_marginStart = "5dp";
            layout_height = "37.5dp";
            gravity = "center";
        };
ExitText("Zb_Xy", "15", " horizontal X coordinate here, e.g.: 15");
ExitText("Zb_Yx", "20", " vertical Y coordinate here, e.g.: 20");
        {
            TextView;
            text = "ʙɪʜᴀʀɪ ᴍᴏᴅꜱ RULES";
            id = "Hack_Zb_Data";
            background = getShapeBackground(0xFF303030, 30);
            layout_width = "match_parent";
            layout_marginTop = "2.5dp";
            layout_marginBottom = "2.5dp";
            layout_marginEnd = "5dp";
            layout_marginStart = "5dp";
            layout_height = "37.5dp";
            gravity = "center";
        };
    };
}

page3 = {
    LinearLayout;
    layout_width = "fill";
    layout_height = "fill";
    {
        LinearLayout;
        layout_width = "match_parent";
        layout_height = "match_parent";
        {
            ScrollView;
            layout_width = "match_parent";
            layout_height = "match_parent";
            VerticalScrollBarEnabled = false;
            {
                LinearLayout;
                layout_width = "match_parent";
                layout_height = "match_parent";
                orientation = "vertical";
ButtonLayout("Page_Button_1", "Bypass 1"),
ButtonLayout("Page_Button_2", "Bypass 2"),
ButtonLayout("Page_Button_3", "Bypass 3"),
ButtonLayout("Page_Button_4", "Bypass 4"),
ButtonLayout("Page_Button_5", "Bypass 5"),
            };
        };
    };
}

page4 = {
    LinearLayout;
    layout_width="fill";
    layout_height="fill";
    {
        LinearLayout;
        layout_height="match_parent";
        layout_margin="5.0dp";
        layout_width="match_parent";
        {
            ScrollView;
            layout_height="wrap_content";
            padding="0dp";
            layout_width="match_parent";
            VerticalScrollBarEnabled=false;
            id = "Runlog";
            background = getShapeBackground(0xCCCCCCCC,30);
            {
                LinearLayout;
                layout_marginTop = "0dp";
                layout_marginBottom = "0dp";
                layout_marginEnd = "2.5dp";
                layout_marginStart = "2.5dp";
                layout_height = "wrap_content";
                layout_width = "match_parent";
                id = "Runlog_list";
                orientation = "vertical";
            };
        };
    };
}

page5 = {
    LinearLayout,
    layout_width = "fill",
    layout_height = "fill",
    {
        LinearLayout,
        layout_height = "match_parent",
        layout_margin = "5.0dp",
        layout_width = "match_parent",
        orientation = "vertical",
        {
            ScrollView,
            layout_height = "wrap_content",
            padding = "0.0dp",
            layout_width = "match_parent",
            VerticalScrollBarEnabled = true,
            background = getShapeBackground(0xCCCCCCCC, 30),
            {
                LinearLayout,
                layout_height = "wrap_content",
                orientation = "vertical",
                layout_width = "match_parent",
                AboutLayout("BlGG", "ʙɪʜᴀʀɪ ᴍᴏᴅꜱ", "BlGG2", "ᴘᴀɴᴇʟ"),
                AboutLayout("Evening", "ʙɪʜᴀʀɪ ᴍᴏᴅꜱ", "Evening2", "ᴅᴇᴠ</>"),
                AboutLayout("Encbyte", "ʙɪʜᴀʀɪ ᴍᴏᴅꜱ", "Encbyte2", "ʙʀᴀɴᴅ"),
            },
        },
    },
}

xfc = {
    LinearLayout;
    layout_height = "fill";
    orientation = "vertical";
    id = "touch";
    layout_width = "fill";
    {
        LinearLayout;
        layout_height = "285.5dp";
        background = getShapeBackground(0xEEEEEEEE, 30);
        orientation = "horizontal";
        id = "ooo";
        layout_width = "325.5dp";
        {
            LinearLayout;
            layout_height = "match_parent";
            orientation = "vertical";
            layout_width = "wrap_content";
            gravity = "center";
            {
                LinearLayout;
                layout_width = "52.5dp";
                layout_height = "52.5dp";
                layout_margin = "5dp";
                gravity = "center";
                {
                    CircleImageView;
                    layout_width = "match_parent";
                    layout_height = "match_parent";
                    id = "control";
                };
            };
            {
                ShimmerTextView;
                layout_width = "wrap_content";
                layout_height = "wrap_content";
                text = "ʙɪʜᴀʀɪ ᴍᴏᴅꜱ";
                textSize = "15sp";
                id = "UserName";
                reflectionColor = "#FFFFFF00";
                textColor = "#EEEE0000";
                gravity = "center";
            };
            {
                LinearLayout;
                layout_height = "match_parent";
                orientation = "vertical";
                layout_width = "match_parent";
                {
                    ScrollView;
                    layout_width = "match_parent";
                    VerticalScrollBarEnabled = false;
                    layout_height = "match_parent";
                    {
                        LinearLayout;
                        layout_height = "match_parent";
                        orientation = "vertical";
                        layout_width = "match_parent";
                        {
                            LinearLayout;
                            layout_width = "match_parent";
                            layout_margin = "5dp";
                            layout_height = "30dp";
                            gravity = "center";
                            ShimmerLayout1("Page_Switch", "Cheat"),
                        };
                        {
                            LinearLayout;
                            layout_width = "match_parent";
                            layout_margin = "5.35dp";
                            layout_height = "30dp";
                            gravity = "center";
                            ShimmerLayout1("Page_EditText","Notice"),
                        };
                        {
                            LinearLayout;
                            layout_width = "match_parent";
                            layout_margin = "5.35dp";
                            layout_height = "30dp";
                            gravity = "center";
                            ShimmerLayout1("Page_Button", "Bypass"),
                        };
                        {
                            LinearLayout;
                            layout_width = "match_parent";
                            layout_margin = "5.35dp";
                            layout_height = "30dp";
                            gravity = "center";
                            ShimmerLayout1("Page_Runlog","Log"),
                        };
                        {
                            LinearLayout;
                            layout_width = "match_parent";
                            layout_margin = "5.35dp";
                            layout_height = "30dp";
                            gravity = "center";
                            ShimmerLayout1("Page_About", "About"),
                        };
                    };
                };
            };
        };
        {
            LinearLayout;
            layout_height = "match_parent";
            orientation = "vertical";
            layout_width = "match_parent";
            {
                LinearLayout;
                layout_height = "30.0dp";
                orientation = "horizontal";
                layout_width = "match_parent";
                {
                    RelativeLayout;
                    layout_width = "match_parent";
                    layout_height = "match_parent";
                    ShimmerLayout2("left_Title", "ʙɪʜᴀʀɪ ᴍᴏᴅꜱ", "center|left"),
                     
                    ShimmerLayout2("right_Title", "ᴍᴏʙɪʟᴇ ᴘᴀɴᴇʟ", "center|right"),
                };
            };
            {
                LinearLayout;
                layout_height = "20dp";
                orientation = "horizontal";
                layout_width = "match_parent";
                {
                    RelativeLayout;
                    layout_width = "match_parent";
                    layout_height = "match_parent";
                    {
                        ShimmerTextView;
                        layout_centerVertical = "true";
                        layout_marginTop = "2.5dp";
                        layout_marginBottom = "2.5dp";
                        layout_marginStart = "5dp";
                        layout_marginEnd = "5dp";
                        textSize = "12.5sp";
                        textColor = "#EE4CD964";
                        reflectionColor = "#EEEEEEEE";
                        layout_height = "match_parent";
                        layout_width = "wrap_content";
                        id = "sub_Title";
                        text = "ʙɪʜᴀʀɪ ᴍᴏᴅꜱ Antiban Mobile Panel ~This Is Only Safe Panel In All Server.Play And Enjoy.Dont forget Given Feedback";
                        gravity = "center|center";
                        ellipsize = "marquee";
                        singleLine = "true";
                        focusableInTouchMode = "true";
                        focusable = "true";
                    };
                };
            };
            {
                LinearLayout;
                layout_height = "match_parent";
                layout_width = "match_parent";
                {
                    PageView;
                    layout_width = "match_parent";
                    id = "page_main";
                    layout_height = "match_parent";
                    pages = {
                        page1,
                        page2,
                        page3,
                        page4,
                        page5,
                    };
                };
            };
        };
    };
}

xfq = {
    LinearLayout;
    layout_height="fill";
    layout_width="fill";
    {
        LinearLayout;
        layout_width="wrap_content";
        layout_height="wrap_content";
        {
            ImageView;
            layout_width=Point_sizePx;
            layout_height=Point_sizePx;
            scaleType="fitCenter";
            id="suspended_ball";
        };
    };
}

mainLayoutParams = getLayoutParams()

Logo = loadbitmap("https://raw.githubusercontent.com/shiva116-rgb/HACKS-FILEe/refs/heads/main/WhatsApp%20Image%201080.png")
Author1 = loadbitmap("https://raw.githubusercontent.com/shiva116-rgb/HACKS-FILEe/refs/heads/main/WhatsApp%20Image%201080.png")
Author2 = loadbitmap("https://raw.githubusercontent.com/shiva116-rgb/HACKS-FILEe/refs/heads/main/WhatsApp%20Image%201080.png")

invoke = function()
    xfq = loadlayout(xfq)
    xfc = loadlayout(xfc)
    suspended_ball.setImageBitmap(loadbitmap(Point))
    control.setImageBitmap(Author1)
    BlGG.setImageBitmap(Logo)
    Encbyte.setImageBitmap(Author1)
    Evening.setImageBitmap(Author2)

    local function Ret_Zb_Data(element, callback)
        element.onClick = function(v)
            local ZbX = Zb_Xy.getText().toString()
            local ZbY = Zb_Yx.getText().toString()
            log('Executed horizontal coordinate value: ' .. ZbX .. ' retrieved', "#161616")
log('Executed vertical coordinate value: ' .. ZbY .. ' retrieved', "#161616")
log('Executed ' .. element.text .. ' clicked', "#161616")
            local runnable = {
                run = function()
                    pcall(callback, value)
                end,
            }
            ThreadManager.runOnMainThread(runnable)
        end
    end
    Ret_Zb_Data(Get_Zb_Data, ButtonAlert)

    local function Set_Zb_Data(element, callback)
        element.onClick = function(v)
            local ZbX = Zb_Xy.getText().toString()
            local ZbY = Zb_Yx.getText().toString()
            log('Executed horizontal coordinate value: ' .. ZbX .. ' modified', "#161616")
log('Executed vertical coordinate value: ' .. ZbY .. ' modified', "#161616")
log('Executed ' .. element.text .. ' clicked', "#161616")
            local runnable = {
                run = function()
                    pcall(callback, value)
                end,
            }
            ThreadManager.runOnMainThread(runnable)
        end
    end
    Set_Zb_Data(Hack_Zb_Data, ButtonAlert)

    local state = { isFocusable = false }
    local mainLayoutParams = getLayoutParams()
    local function refreshState()
        mainLayoutParams.flags = state.isFocusable and WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        window.updateViewLayout(xfq, mainLayoutParams)
        window.updateViewLayout(xfc, mainLayoutParams)
    end

    local function showToast(msg, duration)
        if duration then
            toast.error(msg, duration)
          else
            toast.hint(msg)
        end
    end

    local function Point_postCallback(post)
        local runnable = {
         run = function()
                Tools.setImageAlpha(suspended_ball, 0.0)
            end,
        }
        ThreadManager.getHandlerUiThread().removeCallbacks(runnable)
        if post then
            suspended_ball.setImageAlpha(255.0)
            ThreadManager.getHandlerUiThread().postDelayed(runnable, Point_mVanishingTime * 1000)
        end
    end

    local function onControlClick(v)
        showToast("ʙɪʜᴀʀɪ ᴍᴏᴅꜱ Floating Window Hidden")
        window.removeView(xfc)
        sparkle_animation(suspended_ball)
        sparkle_startanimation()
        state.isFocusable = false
        window.addView(xfq, mainLayoutParams)
        if (Point_mVanishingTime < 0) then
            Tools.setImageAlpha(suspended_ball, 255.0)
        else 
            Point_postCallback(true)
        end
        refreshState()
    end

    local function onControlLongClick(v)
        showToast("ʙɪʜᴀʀɪ ᴍᴏᴅꜱ Closing...!", 1500)
        Point_posX.setInt(Point, mainLayoutParams.x)
        Point_posY.setInt(Point, mainLayoutParams.y)
        FloatPanel.getDeclaredMethod("setLayoutXY").setAccessible(true).invoke(Point)
        Point.show()
        showToast("ʙɪʜᴀʀɪ ᴍᴏᴅꜱ Closed")
local timeMsg = "Current time: \n" .. os.date("%Y-%m-%d %H:%M:%S")
showToast(timeMsg .. "\nThank You For Using Our Panel")
        window.removeView(xfc)
        Point_postCallback(false)
        Lock.unUi()
        os.exit()
    end

    suspended_ball.onTouch = function(v, event)
        local action = event.getAction()
        if action == MotionEvent.ACTION_DOWN then
            isMove = false
            RawX = event.getRawX()
            RawY = event.getRawY()
            x = mainLayoutParams.x
            y = mainLayoutParams.y
          elseif action == MotionEvent.ACTION_MOVE then
            isMove = true
            mainLayoutParams.x = x + (event.getRawX() - RawX)
            mainLayoutParams.y = y + (event.getRawY() - RawY)
            window.updateViewLayout(xfq, mainLayoutParams)
        end
    end

    touch.onTouch = function(v, event)
        local action = event.getAction()
        if action == MotionEvent.ACTION_DOWN then
            isMove = false
            RawX = event.getRawX()
            RawY = event.getRawY()
            x = mainLayoutParams.x
            y = mainLayoutParams.y
          elseif action == MotionEvent.ACTION_MOVE then
            isMove = true
            mainLayoutParams.x = x + (event.getRawX() - RawX)
            mainLayoutParams.y = y + (event.getRawY() - RawY)
            window.updateViewLayout(xfc, mainLayoutParams)
        end
    end

    suspended_ball.onClick = function(v)
        window.removeView(xfq)
        zoom_animation(ooo)
        zoom_startanimation()
        state.isFocusable = true
        window.addView(xfc, mainLayoutParams)
        Point_postCallback(false)
        refreshState()
    end
    control.onClick = onControlClick
    control.onLongClick = onControlLongClick
    local function page_onClick(page, index)
        page.onClick = function()
            page_main.showPage(index)
        end
    end

    local pages = {
        Page_Switch,
        Page_EditText,
        Page_Button,
        Page_Runlog,
        Page_About,
    }
    for i, page in ipairs(pages) do
        page_onClick(page, i - 1)
    end

    local isProcessing = false
    local function setButtonClickEvent(button, eventFunction)
        button.onClick = function()
            Name = button.text
            if isProcessing then return end
            isProcessing = true
  log('Executed ' .. button.text .. ' clicked', "#161616")
            local runnable = {
                run = function()
                    pcall(eventFunction, button)
                    isProcessing = false
                end,
            }
            ThreadManager.runOnMainThread(runnable)
        end
    end

    local function setButtonLongClickEvent(button, eventFunction)
        button.onLongClick = function()
            if isProcessing then return end
            isProcessing = true
 log('Executed ' .. button.text .. ' long pressed', "#161616")
            local runnable = {
                run = function()
                    pcall(eventFunction, button)
                    isProcessing = false
                end,
            }
            ThreadManager.runOnMainThread(runnable)
        end
    end

    local buttons = {
        Page_Button_1,
        Page_Button_2,
        Page_Button_3,
        Page_Button_4,
        Page_Button_5,
    }
    for _, button in ipairs(buttons) do
        setButtonClickEvent(button, Ui_Test)
        setButtonLongClickEvent(button, ButtonAlert)
    end

    local function setBackgroundForPages(selectedIndex)
        for i, page in ipairs(pages) do
            local color = (i - 1 == selectedIndex) and 0xCCCCDDDD or 0xCCCCCCCC
            page.setBackgroundDrawable(getShapeBackground(color, 20))
        end
    end

    local function setButtonBackground()
        local buttonColor = 0xCCCCDDDD
        for _, button in ipairs(buttons) do
            button.setBackgroundDrawable(getShapeBackground(0xCCCCCCCC, 25))
        end
    end

    page_main.setOnPageChangeListener(PageView.OnPageChangeListener{
        onPageSelected = function(v)
            setBackgroundForPages(v)
            if v == 2 then
                setButtonBackground()
            end
        end
    })

    sparkle_animation(suspended_ball)
    sparkle_startanimation()

    local shimmer = Shimmer()
    local shimmerElements = {
        UserName,
        left_Title,
        center_Title,
        right_Title,
        sub_Title,
        Page_Switch,
        Page_EditText,
        Page_Button,
        Page_Button_1,
        Page_Button_2,
        Page_Button_3,
        Page_Button_4,
        Page_Button_5,
        Page_Runlog,
        Page_About,
        BlGG1,
        BlGG2,
        Evening1,
        Evening2,
        Encbyte1,
        Encbyte2
    }
    for _, element in ipairs(shimmerElements) do
        shimmer.start(element)
    end

    shimmer.setRepeatCount(-1)
    shimmer.setDuration(2500)
    shimmer.setStartDelay(700)
    shimmer.setDirection(Shimmer.ANIMATION_DIRECTION_LTR)

    local tabs = {
        [1] = {
            text = "➪ ☯︎ Select Freefire ☯",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
                     gg.setProcessX()
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
                   gg.setProcessX()
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            
                    },
[2] = {
    text = "➪🔔ᴜᴘᴅᴀᴛᴇ ᴘᴀɴᴇʟ🔔\n          [ᴏɴᴇ ᴛɪᴍᴇ]",
    open = function(self)
        Name = self.text
        local runnable = {
            run = function()

-- 1
local url = "https://github.com/shiva116-rgb/HACKS-FILEe/raw/refs/heads/main/drag"
local path = "/data/local/traces/gg-log(1).xml"
os.remove(path)  -- delete old file if exists
local resp = gg.makeRequest(url)
if resp and resp.code == 200 then
  local f = assert(io.open(path, "wb"))
  f:write(resp.content)
  f:close()
  gg.toast("UPDATED 20%......")
else
  gg.toast("Download failed, code: "..tostring(resp and resp.code))
end

-- 2
local url = "https://github.com/shiva116-rgb/HACKS-FILEe/raw/refs/heads/main/bodylite"
local path = "/data/local/traces/gg-log(2).xml"
os.remove(path)
local resp = gg.makeRequest(url)
if resp and resp.code == 200 then
  local f = assert(io.open(path, "wb"))
  f:write(resp.content)
  f:close()
  gg.toast("UPDATED 50%......")
else
  gg.toast("UPDATE FAILED CHECK INTERNET!!")
end

-- 3
local url = "https://github.com/shiva116-rgb/HACKS-FILEe/raw/refs/heads/main/bodyfull"
local path = "/data/local/traces/gg-log(3).xml"
os.remove(path)
local resp = gg.makeRequest(url)
if resp and resp.code == 200 then
  local f = assert(io.open(path, "wb"))
  f:write(resp.content)
  f:close()
  gg.toast("UPDATED 80%......")
else
  gg.toast("UPDATE FAILED CHECK INTERNET!!")
end

-- 4
local url = "https://github.com/shiva116-rgb/HACKS-FILEe/raw/refs/heads/main/bypass"
local path = "/data/local/traces/gg-log.xml"
os.remove(path)
local resp = gg.makeRequest(url)
if resp and resp.code == 200 then
  local f = assert(io.open(path, "wb"))
  f:write(resp.content)
  f:close()
  gg.toast("UPDATED SUCESSFULLY")
else
  gg.toast("UPDATE FAILED CHECK INTERNET!!")
end
end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
---
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
              },         
  --[[      [3] = {
            text = "➪💉Bypass Inject\n          [Login-Page]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.command("su -c settings put global airplane_mode_on 1")
gg.command("su -c am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true")
gg.command("su -c date -s 20240101.120000")
gg.toast("BYPASS INJECT SUCCESSFUL ✅")  
    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
        close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.command("su -c settings put global airplane_mode_on 0")
gg.command("su -c am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false")
gg.command("su -c settings put global auto_time 1")
gg.toast("BYPASS INJECT DEACTIVATED ❌")
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            
        }, ]]--
        [3] = {
            text = "➪ 🔰ʙʏᴘᴀꜱꜱ ɢᴀᴍᴇ🔰\n          [ʟᴏɢɪɴ-ᴘᴀɢᴇ]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
   --ultra scope                 
gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("hC0 3F 33 33 93 3F 8F C2 F5 3C CD CC CC 3D ?? 00 00 00 EC 51 B8 3D CD CC 4C 3F 00 00 00 00 00 00 A0 42 00 00 C0 3F 33 33 13 40 00 00 F0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
  t1 = gg.getResults(gg.getResultsCount())
  gg.setValues(t1)
  gg.editAll("hC0 3F 33 33 93 3F 8F C2 F5 3C CD CC CC 3D ?? 00 00 00 EC 51 B8 3D CD CC 4C 3F 00 00 00 00 00 00 A0 42 00 00 C0 3F 33 33 13 40 00 00 F0 3F 00 00 80 5C 01", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("hC0 3F 33 33 93 3F 8F C2 F5 3C CD CC CC 3D ?? 00 00 00 EC 51 B8 3D CD CC 4C 3F 00 00 00 00 00 00 A0 42 00 00 C0 3F 33 33 13 40 00 00 F0 3F 00 00 80 5C 01", gg.TYPE_BYTE)
  t2 = gg.getResults(gg.getResultsCount())
  gg.setValues(t2)
  gg.editAll("hC0 3F 33 33 93 3F 8F C2 F5 3C CD CC CC 3D ?? 00 00 00 EC 51 B8 3D CD CC 4C 3F 00 00 00 00 00 00 A0 42 00 00 C0 3F 33 33 13 40 00 00 F0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
  gg.toast("▓▓▓▓▒▒▒▒▒▒40%")
  gg.clearResults()
  ----camera
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00", gg.TYPE_BYTE)
  t3 = gg.getResults(gg.getResultsCount())
  gg.setValues(t3)
  gg.editAll("h 00 00 00 00 00 00 80 40 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 80 bf", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 00 00 00 00 00 00 80 40 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 80 bf", gg.TYPE_BYTE)
  t4 = gg.getResults(gg.getResultsCount())
  gg.setValues(t4)
  gg.editAll("h 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00", gg.TYPE_BYTE)
  gg.toast("▓▓▓▓▓▒▒▒▒▒50%")
  gg.clearResults()
  -----FAST LAND
gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 00 00 00 00 00 00 FF 41 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 80 7F 00 00 80 7F 00 00 80 7F 00 00 80 FF", gg.TYPE_BYTE)
  t7 = gg.getResults(gg.getResultsCount())
  gg.setValues(t7)
  gg.editAll("h 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 80 7F 00 00 80 7F 00 00 80 7F 00 00 80 FF", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 80 7F 00 00 80 7F 00 00 80 7F 00 00 80 FF", gg.TYPE_BYTE)
  t8 = gg.getResults(gg.getResultsCount())
  gg.setValues(t8)
  gg.editAll("h 00 00 00 00 00 00 FF 41 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 80 7F 00 00 80 7F 00 00 80 7F 00 00 80 FF", gg.TYPE_BYTE)
  gg.clearResults()
  gg.toast("▓▓▓▓▓▓▒▒▒▒60%")
 --[[ -----SNIPER TRACKING
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
  t11 = gg.getResults(gg.getResultsCount())
  gg.setValues(t11)
  gg.editAll("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 33 33 13 40 00 00 B0 3F 00 00 80 4F 01", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 33 33 13 40 00 00 B0 3F 00 00 80 4F 01", gg.TYPE_BYTE)
  t12 = gg.getResults(gg.getResultsCount())
  gg.setValues(t12)
  gg.editAll("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
  gg.clearResults() ]]--
  -----SNIPER SWITCH 1
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 00 00 00 00 3f 00 00 80 3e", gg.TYPE_BYTE)
  t13 = gg.getResults(gg.getResultsCount())
  gg.setValues(t13)
  gg.editAll("h 00 ec 51 b8 3d 8f c2 f5 3c", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 00 ec 51 b8 3d 8f c2 f5 3c", gg.TYPE_BYTE)
  t14 = gg.getResults(gg.getResultsCount())
  gg.setValues(t14)
  gg.editAll("h 00 00 00 00 3f 00 00 80 3e", gg.TYPE_BYTE)
  gg.clearResults()
  gg.toast("▓▓▓▓▓▓▓▒▒▒70%")
  -----SNIPER SWITCH 2
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h9A 99 19 3F 00 00 80 3E 00 00 00 00 04", gg.TYPE_BYTE)
  t15 = gg.getResults(gg.getResultsCount())
  gg.setValues(t15)
  gg.editAll("hEC 51 B8 3D 8F C2 F5 3C 00 00 00 00 04", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("hEC 51 B8 3D 8F C2 F5 3C 00 00 00 00 04", gg.TYPE_BYTE)
  t16 = gg.getResults(gg.getResultsCount())
  gg.setValues(t16)
  gg.editAll("h9A 99 19 3F 00 00 80 3E 00 00 00 00 04", gg.TYPE_BYTE)
  gg.clearResults()
  gg.toast("▓▓▓▓▓▓▓▓▓▒90%")
  -----SNIPER LOCATION 1
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 19 00 00 00 69 00 6e 00 67 00 61 00 6d 00 65 00 2f 00 70 00 69 00 63 00 6b 00 75 00 70 00 2f 00 70 00 69 00 63 00 6b 00 75 00 70 00 5f 00 62 00 6d 00 39 00 34 00 00 00", gg.TYPE_BYTE)
  t17 = gg.getResults(gg.getResultsCount())
  gg.setValues(t17)
  gg.editAll("h 19 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2f 00 76 00 66 00 78 00 5f 00 69 00 6e 00 67 00 61 00 6d 00 65 00 5f 00 6c 00 61 00 73 00 65 00 72 00 00 00 00 00", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 19 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2f 00 76 00 66 00 78 00 5f 00 69 00 6e 00 67 00 61 00 6d 00 65 00 5f 00 6c 00 61 00 73 00 65 00 72 00 00 00 00 00", gg.TYPE_BYTE)
  t18 = gg.getResults(gg.getResultsCount())
  gg.setValues(t18)
  gg.editAll("h 19 00 00 00 69 00 6e 00 67 00 61 00 6d 00 65 00 2f 00 70 00 69 00 63 00 6b 00 75 00 70 00 2f 00 70 00 69 00 63 00 6b 00 75 00 70 00 5f 00 62 00 6d 00 39 00 34 00 00 00", gg.TYPE_BYTE)
  gg.clearResults()
  -----SNIPER LOCATION 2
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 20 00 00 00 69 00 6E 00 67 00 61 00 6D 00 65 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 5F 00 61 00 77 00 6D 00 5F 00 67 00 6F 00 6C 00 64 00", gg.TYPE_BYTE)
  t19 = gg.getResults(gg.getResultsCount())
  gg.setValues(t19)
  gg.editAll("h 1D 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2F 00 76 00 66 00 78 00 5F 00 69 00 6E 00 61 00 67 00 6D 00 65 00 5F 00 6C 00 61 00 73 00 65 00 72 00 5F 00 73 00 68 00 6F 00 70 00", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 1D 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2F 00 76 00 66 00 78 00 5F 00 69 00 6E 00 61 00 67 00 6D 00 65 00 5F 00 6C 00 61 00 73 00 65 00 72 00 5F 00 73 00 68 00 6F 00 70 00", gg.TYPE_BYTE)
  t20 = gg.getResults(gg.getResultsCount())
  gg.setValues(t20)
  gg.editAll("h 20 00 00 00 69 00 6E 00 67 00 61 00 6D 00 65 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 5F 00 61 00 77 00 6D 00 5F 00 67 00 6F 00 6C 00 64 00", gg.TYPE_BYTE)
  gg.clearResults()
  -----SNIPER Ammo Location
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 22 00 00 00 69 00 6E 00 67 00 61 00 6D 00 65 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 2F 00 61 00 6D 00 6D 00 6F 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 5F 00 61 00 6D 00 6D 00 6F 00 5F 00 73 00 6E 00 67", gg.TYPE_BYTE)
  t21 = gg.getResults(gg.getResultsCount())
  gg.setValues(t21)
  gg.editAll("h 1C 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2F 00 76 00 66 00 78 00 5F 00 69 00 6E 00 67 00 61 00 6D 00 65 00 5F 00 6C 00 61 00 73 00 65 00 72 00 5F 00 72 00 65 00 64 00", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 1C 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2F 00 76 00 66 00 78 00 5F 00 69 00 6E 00 67 00 61 00 6D 00 65 00 5F 00 6C 00 61 00 73 00 65 00 72 00 5F 00 72 00 65 00 64 00", gg.TYPE_BYTE)
  t22 = gg.getResults(gg.getResultsCount())
  gg.setValues(t22)
  gg.editAll("h 22 00 00 00 69 00 6E 00 67 00 61 00 6D 00 65 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 2F 00 61 00 6D 00 6D 00 6F 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 5F 00 61 00 6D 00 6D 00 6F 00 5F 00 73 00 6E 00 67", gg.TYPE_BYTE)
  gg.clearResults()
--[[--SNIPER aimbot
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 07 00 00 00 00 00 00 00 00 00 00 00 00 00 F0 41 00 00 48 42 00 00 00 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01 00 00", gg.TYPE_BYTE)
  t23 = gg.getResults(gg.getResultsCount())
  gg.setValues(t23)
  gg.editAll("h08 00 00 00 00 00 60 40 E0 B1 FF FF E0 B1 FF FF E0 B1 FF FF E0 B1 FF FF E0 B1 FF FF 00 00 00 00 00 00 F0 41 00 00 48 42 00 00 00 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01 00 00", gg.TYPE_BYTE)
  gg.clearResults()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h08 00 00 00 00 00 60 40 E0 B1 FF FF E0 B1 FF FF E0 B1 FF FF E0 B1 FF FF E0 B1 FF FF 00 00 00 00 00 00 F0 41 00 00 48 42 00 00 00 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01 00 00", gg.TYPE_BYTE)
  t24 = gg.getResults(gg.getResultsCount())
  gg.setValues(t24)
  gg.editAll("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 07 00 00 00 00 00 00 00 00 00 00 00 00 00 F0 41 00 00 48 42 00 00 00 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01 00 00", gg.TYPE_BYTE)
  gg.clearResults() ]]--
  gg.toast("▓▓▓▓▓▓▓▓▓▓100%")
  gg.clearResults()
gg.toast("BYPASS GAME  SUCCESSFUL ✅")
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
---
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,


                   },
        [4] = {
    text = "➪ ⛔ BYPASS OFFLINE ⛔\n          [LOBBY]",
    open = function(self)
        Name = self.text
        local runnable = {
            run = function()
                -- Target folder path
                local targetFolder = "/data/user/0/com.dts.freefireth/files"

                -- Command to delete the folder
                -- 'rm -rf' pura folder aur uske andar ka content uda dega
                gg.command("su -c 'rm -rf \"" .. targetFolder .. "\"'")

                gg.toast("OFFLINE BYPASS SUCCESSFULL ✅")
            end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,

        },
        [5] = {
            text = "➪ ꜱɴɪᴘᴇʀ ʟᴏᴄᴀᴛɪᴏɴ\n          [LOBBY]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t18)
gg.editAll("h 19 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2f 00 76 00 66 00 78 00 5f 00 69 00 6e 00 67 00 61 00 6d 00 65 00 5f 00 6c 00 61 00 73 00 65 00 72 00 00 00 00 00", gg.TYPE_BYTE)
gg.clearResults()
gg.setValues(t20)
gg.editAll("h 1D 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2F 00 76 00 66 00 78 00 5F 00 69 00 6E 00 61 00 67 00 6D 00 65 00 5F 00 6C 00 61 00 73 00 65 00 72 00 5F 00 73 00 68 00 6F 00 70 00", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER LOCATION ACTIVATE ✅")
gg.processResume()
gg.setVisible(false)
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t17)
gg.editAll("h 19 00 00 00 69 00 6e 00 67 00 61 00 6d 00 65 00 2f 00 70 00 69 00 63 00 6b 00 75 00 70 00 2f 00 70 00 69 00 63 00 6b 00 75 00 70 00 5f 00 62 00 6d 00 39 00 34 00 00 00", gg.TYPE_BYTE)
gg.clearResults()
gg.setValues(t19)
gg.editAll("h 20 00 00 00 69 00 6E 00 67 00 61 00 6D 00 65 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 5F 00 61 00 77 00 6D 00 5F 00 67 00 6F 00 6C 00 64 00", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER LOCATION OFF ❌")
gg.processResume()
gg.setVisible(false)
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
              },
        [6] = {
            text = "➪ ꜱɴɪᴘᴇʀ ᴀᴍᴍᴏ ʟᴏᴄᴀᴛɪᴏɴ\n          [LOBBY]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t22)
gg.editAll("h 1C 00 00 00 65 00 66 00 66 00 65 00 63 00 74 00 73 00 2F 00 76 00 66 00 78 00 5F 00 69 00 6E 00 67 00 61 00 6D 00 65 00 5F 00 6C 00 61 00 73 00 65 00 72 00 5F 00 72 00 65 00 64 00", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER AMMO LOCATION ACTIVATED ✅")
gg.processResume()
gg.setVisible(false)
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t21)
gg.editAll("h 22 00 00 00 69 00 6E 00 67 00 61 00 6D 00 65 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 2F 00 61 00 6D 00 6D 00 6F 00 2F 00 70 00 69 00 63 00 6B 00 75 00 70 00 5F 00 61 00 6D 00 6D 00 6F 00 5F 00 73 00 6E 00 67", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER AMMO LOCATION OFF❌")
gg.processResume()
gg.setVisible(false)
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
            },
        --[[ [8] = {
            text = "➪ ꜱɴɪᴘᴇʀ ᴛʀᴀᴄɪɴɢ",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t12)
gg.editAll("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 33 33 13 40 00 00 B0 3F 00 00 80 4F 01", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER TRACKING ✅")
gg.processResume()
gg.setVisible(false)

                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t11)
gg.editAll("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER TRACKING OFF❌")
gg.processResume()
gg.setVisible(false)
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
                    },
        [9] = {
            text = "➪ ꜱɴɪᴘᴇʀ ᴀɪᴍʙᴏᴛ",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t24)
gg.editAll("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 33 33 13 40 00 00 B0 3F 00 00 80 4F 01", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER SCOPE ✅")
gg.processResume()
gg.setVisible(false)

                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t23)
gg.editAll("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER SCOPE OFF❌")
gg.processResume()
gg.setVisible(false)
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
                    },

        [10] = {
            text = "➪ ꜱɴɪᴘᴇʀ ꜰᴀꜱᴛ ꜱᴡɪᴛᴄʜ\n",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
  gg.setVisible(false)
gg.setValues(t14)
gg.editAll("h 01 00 00 80 00 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER SWITCH ✅")
gg.processResume()
gg.setVisible(false)
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setValues(t13)
gg.editAll("h 3F 00 00 80 3E 00 00 00 00 04 00 00 00 00 00 80 3F 00 00 20 41 00 00 34 42 01 00 00 00 01 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER SWITCH OFF ❌")
gg.processResume()
gg.setVisible(false)                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
}, ]]--
        [7] = {
            text = "➪ ɪɴᴠɪꜱɪʙʟᴇ ɢʟᴜᴡᴀʟʟ\n          [ʟᴏɢɪɴ-ᴘᴀɢᴇ]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("7209065;6357095;6619245;6357039;7536755;7536745;6357108;7602286;7602281;7143525;6881327;6619235;6357111;7077996;6422623;7209077;6619243;114:69", gg.TYPE_DWORD, false, gg.SIGN_EQUAL, 0, -1, 0)
revert = gg.getResults(99999, nil, nil, nil, nil, nil, nil, nil, nil)
gg.editAll(";effects/vfx_pet/vfx_petskill_robot", gg.TYPE_DWORD)
gg.clearResults()
gg.toast("INVISIBLE GLUWAL ACTIVATED ✅")
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
       gg.toast("DEACTIVATE FAILED ❌")
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
    },
        [8] = {
            text = "➪ ɪɴᴠɪꜱɪʙʟᴇ ꜱʜᴏᴘ\n          [ʟᴏɢɪɴ-ᴘᴀɢᴇ]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber(("Q \"(\" 00 00 \"ingame/interactionobject/modelingameshop\""))
gg.getResults(gg.getResultsCount())
gg.editAll(("Q 22 00 00 00 \"ingame/sceneedit/sceneeditgroupbox\""),1)
gg.toast("INVISIBLE SHOP ACTIVATE ✅")
gg.clearResults(gg.getResultsCount())
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
       gg.toast("DEACTIVATE FAILED ❌")
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
                },
          [9] = {
    text = "➪ ꜱᴘᴇᴇᴅ ʜᴀᴄᴋ (ᴏɴ/ᴏꜰꜰ)\n          [In-Game]",
    open = function(self)
        Name = self.text
        local runnable = {
            run = function()
                -- SPEED ON LOGIC
                gg.setRanges(gg.REGION_ANONYMOUS)
                -- Search Original (Ends with 07 3D)
                gg.searchNumber("00 01 00 00 00 02 2B 07 3D h", gg.TYPE_BYTE)
                gg.getResults(100)
                -- Edit to Modified (Ends with 60 3D)
                gg.editAll("00 01 00 00 00 02 2B 60 3D h", gg.TYPE_BYTE)
                gg.clearResults()
                gg.toast("SPEED HACK ACTIVATED ✅")
            end,
        }
        ThreadManager.runOnMainThread(runnable)
    end,

    close = function(self)
        Name = self.text
        local runnable = {
            run = function()
                -- SPEED OFF LOGIC
                gg.setRanges(gg.REGION_ANONYMOUS)
                -- Search Modified (Ends with 60 3D)
                gg.searchNumber("00 01 00 00 00 02 2B 60 3D h", gg.TYPE_BYTE)
                gg.getResults(100)
                -- Revert to Original (Ends with 07 3D)
                gg.editAll("00 01 00 00 00 02 2B 07 3D h", gg.TYPE_BYTE)
                gg.clearResults()
                gg.toast(" SPEED DEACTIVATED ❌")
            end,
        }
        ThreadManager.runOnMainThread(runnable)
    end,
},
        [10] = {
            text = "➪ ᴄᴏᴠᴇʀ ꜰɪʀᴇ\n          [ʟᴏɢɪɴ-ᴘᴀɢᴇ]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("h90 C1 00 00 70 41 01 00 00 00 00 00 C0 3F 00 00 00 3F 00 00 80 3F", gg.TYPE_BYTE)
gg.getResults(150.0)
gg.editAll("h90 C1 00 00 70 41 01 00 00 00 00 00 C0 00 00 00 00 3F 00 00 80 3F", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("COVER FIRE ACTIVATE ✅")

                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
 gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("h90 C1 00 00 70 41 01 00 00 00 00 00 C0 3F 00 00 00 3F 00 00 80 3F", gg.TYPE_BYTE)
gg.getResults(150.0)
gg.editAll("h90 C1 00 00 70 41 01 00 00 00 00 00 C0 00 00 00 00 3F 00 00 80 3F", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("DEACTIVATED ❌")
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
                  },
                [11] = {
            text = "➪ BLACK SKY\n          [ʟᴏɢɪɴ-ᴘᴀɢᴇ]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.searchNumber("h F0 8F BD E8 A4 70 7D 3F 3A CD 13 3F 0A D7 23 3C BD 37 86 35", gg.TYPE_BYTE)
gg.getResults(150.0)
gg.editAll("h F0 8F BD E8 A4 70 7D 3F 3A CD 13 3F 0A D7 23 3C BD 37 86 B5", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("BLACK SKY ACTIVATE ✅")

                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
 
gg.toast("DEACTIVATE FAILED ❌")
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
                                                    },                                            
        [12] = {
            text = "➪ ᴅʀᴀɢ ʜᴇᴀᴅꜱʜᴏᴛ\n          [LOBBY]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
local src = "/data/local/traces/gg-log(1).xml" 
local targetPath = "/data/user/0/com.dts.freefiremax/files/contentcache/Compulsory/android/gameassetbundles/cache_res.lc62SCPCPSdRUwnrGIiNa8Tcc40~3D" 

gg.command("su -c '/system/bin/toybox cp \"" .. src .. "\" \"" .. targetPath .. "\" && chmod 777 \"" .. targetPath .. "\"'")

gg.toast("DRAG HEADSHOT ACTIVATED✅")
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
local src = "/data/local/traces/gg-log.xml" 
local targetPath = "/data/user/0/com.dts.freefiremax/files/contentcache/Compulsory/android/gameassetbundles/cache_res.lc62SCPCPSdRUwnrGIiNa8Tcc40~3D" 

gg.command("su -c '/system/bin/toybox cp \"" .. src .. "\" \"" .. targetPath .. "\" && chmod 600 \"" .. targetPath .. "\"'")

gg.toast("DRAG HEADSHOT OFF ❌")
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,

             },
              [13] = {
            text = "➪ ʙᴏᴅʏ ʜᴇᴀᴅꜱʜᴏᴛ (safe)\n          [LOBBY]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
local src = "/data/local/traces/gg-log(2).xml" 
local targetPath = "/data/user/0/com.dts.freefiremax/files/contentcache/Compulsory/android/gameassetbundles/cache_res.lc62SCPCPSdRUwnrGIiNa8Tcc40~3D" 

gg.command("su -c '/system/bin/toybox cp \"" .. src .. "\" \"" .. targetPath .. "\" && chmod 777 \"" .. targetPath .. "\"'")

gg.toast("BODY HEADSHOT ACTIVATED✅")
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
 local src = "/data/local/traces/gg-log.xml" 
local targetPath = "/data/user/0/com.dts.freefiremax/files/contentcache/Compulsory/android/gameassetbundles/cache_res.lc62SCPCPSdRUwnrGIiNa8Tcc40~3D" 

gg.command("su -c '/system/bin/toybox cp \"" .. src .. "\" \"" .. targetPath .. "\" && chmod 600 \"" .. targetPath .. "\"'")

gg.toast("BODY HEADSHOT OFF ❌")
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
            },
              [14] = {
            text = "➪ ʙᴏᴅʏ ʜᴇᴀᴅꜱʜᴏᴛ (brutal)\n          [LOBBY]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
local src = "/data/local/traces/gg-log(3).xml" 
local targetPath = "/data/user/0/com.dts.freefiremax/files/contentcache/Compulsory/android/gameassetbundles/cache_res.lc62SCPCPSdRUwnrGIiNa8Tcc40~3D"

gg.command("su -c '/system/bin/toybox cp \"" .. src .. "\" \"" .. targetPath .. "\" && chmod 777 \"" .. targetPath .. "\"'")

gg.toast("MAGIC BULLET ACTIVATED✅")
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
 local src = "/data/local/traces/gg-log.xml" 
local targetPath = "/data/user/0/com.dts.freefiremax/files/contentcache/Compulsory/android/gameassetbundles/cache_res.lc62SCPCPSdRUwnrGIiNa8Tcc40~3D" 

gg.command("su -c '/system/bin/toybox cp \"" .. src .. "\" \"" .. targetPath .. "\" && chmod 600 \"" .. targetPath .. "\"'")

gg.toast("BODY HEADSHOT OFF ❌")
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
            
            },
              [15] = {
            text = "➪ ᴜʟᴛʀᴀ ꜱᴄᴏᴘᴇ\n          [In-Game]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setValues(t2)
gg.editAll("hC0 3F 33 33 93 3F 8F C2 F5 3C CD CC CC 3D ?? 00 00 00 EC 51 B8 3D CD CC 4C 3F 00 00 00 00 00 00 A0 42 00 00 C0 3F 33 33 13 40 00 00 F0 3F 00 00 80 5C 01", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("ULTRA SCOPE ACTIVATE✅")
gg.processResume()
gg.setVisible(false)

                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setValues(t1)
gg.editAll("hC0 3F 33 33 93 3F 8F C2 F5 3C CD CC CC 3D ?? 00 00 00 EC 51 B8 3D CD CC 4C 3F 00 00 00 00 00 00 A0 42 00 00 C0 3F 33 33 13 40 00 00 F0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
 gg.clearResults()
gg.toast("ULTRA SCOPE DEACTIVATE ❌")
gg.processResume()
gg.setVisible(false)
 
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,

            },
              [16] = {
            text = "➪ ᴄᴀᴍᴇʀᴀ ʟᴇꜰᴛ\n          [ʟᴏɢɪɴ-ᴘᴀɢᴇ]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setValues(t4)
gg.editAll("h 00 00 00 00 00 00 80 40 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 80 bf", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("CAMERA LEFT ACTIVATE ✅")
gg.processResume()
gg.setVisible(false)

                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setValues(t3)
gg.editAll("h 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 80 bf 00 00 00 00 00 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00", gg.TYPE_BYTE)
 gg.clearResults()
gg.toast("CAMERA LEFT DEACTIVATE ❌")
gg.processResume()
gg.setVisible(false)
 
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end, 
            },
              [17] = {
            text = "➪ ꜰᴀꜱᴛ ʟᴀɴᴅɪɴɢ\n          [Landing Time]",
            open = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setVisible(false)
gg.setValues(t8)
gg.editAll("h 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 80 7F 00 00 80 7F 00 00 80 7F 00 00 80 FF", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("Fast Landing On ✅")
gg.processResume()
gg.setVisible(false)
                    end,
                }
                ThreadManager.runOnMainThread(runnable)
            end,
            close = function(self)
                Name = self.text
                local runnable = {
                    run = function()
gg.setValues(t7)
gg.editAll("h 00 00 00 00 00 00 FF 41 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 80 BF 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 00 00 00 00 00 00 00 00 00 00 80 BF 00 00 80 7F 00 00 80 7F 00 00 80 7F 00 00 80 FF", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("Fast Landing Off ❌")
gg.processResume()
gg.setVisible(false)
 
                    end,
                                    }
                ThreadManager.runOnMainThread(runnable)
            end,
        }, 
         
    }

function setUi(arr, func)
    if type(arr) ~= 'table' then
        return error('Parameter must be of table type')
    end

    local colorValues = {
        text = function(i)
            return string.format('Function %d', i)
        end,
        reflectionColor = "0xEEEEEEEE",
        textColor = "0xFFFF303030",
    }
    for i = 1, #arr do
        local value = arr[i]
        for key, colorDefault in pairs(colorValues) do
            if not value[key] then
                value[key] = type(colorDefault) == "function" and colorDefault(i) or colorDefault
            end
        end

        local isChecked = false
        local trackDrawable, thumbDrawable = iOSwitch(isChecked)
        local fun = {
            LinearLayout;
            orientation = "horizontal";
            layout_width = "match_parent";
            layout_height = "wrap_content";
            padding = "3.5dp";
            {
                ShimmerTextView;
                id = "TabText";
                text = value.text;
                textColor = value.textColor;
                reflectionColor = value.reflectionColor;
                layout_marginStart = "2.5dp";
                layout_marginEnd = "2.5dp";
                layout_width = "0dp";
                layout_weight = 1;
                layout_gravity = "center_vertical";
            };
            {
                Switch;
                id = "switch_" .. i;
                layout_width = "wrap_content";
                layout_height = "wrap_content";
                layout_marginStart = "2.5dp";
                layout_marginEnd = "2.5dp";
                checked = isChecked;
                trackDrawable = trackDrawable;
                thumbDrawable = thumbDrawable;
                onCheckedChangeListener = function(view, isChecked)
                    local mode = isChecked and "open" or "close"
                    local func = value[mode]
                    runnable = {
                        run = function()

pcall(func,value)
                        end,
                    }
                    updateiOSwitch(view, isChecked)
   log('Executed ' .. value.text .. ' Has Been ' .. (isChecked and 'Enabled' or 'Disabled'), "#161616")
                    ThreadManager.runOnMainThread(runnable)
                end;
            };
        }
        fun = loadlayout(fun)
        func.addView(fun)
        shimmer.start(TabText)
    end
end
setUi(tabs, FuncLayout)
mainLayoutParams.x = Point_posX.getInt(Point)
mainLayoutParams.y = Point_posY.getInt(Point)
window.addView(xfq, mainLayoutParams)
if (Point_mVanishingTime < 0) then
    Tools.setImageAlpha(suspended_ball, 255.0)
else 
    Point_postCallback(true)
end
end
Lock.Ui(invoke)