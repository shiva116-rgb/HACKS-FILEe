<?php

date_default_timezone_set('Asia/Kolkata');

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    include 'Extra/403.html';
    exit();
}

include 'Database.php';
include 'Extra/Key.php';

if ($conn === null) {
    die("Database connection failed.");
}

// SCRIPT PATHS
$Free1 = 'Scripts/FreeGame1.lua'; 
$Free2 = 'Scripts/FreeGame2.lua'; 
$Free3 = 'Scripts/FreeGame3.lua'; 
$Premium1 = 'Scripts/Lite.lua'; 
$Premium2 = 'Scripts/Basic.lua'; 
$Premium3 = 'Scripts/Brutal.lua'; 
    
function xorEncrypt($data, $key) {
    $out = '';
    for ($i = 0; $i < strlen($data); $i++) {
        $out .= $data[$i] ^ $key[$i % strlen($key)];
    }
    return $out;
}

function exitAlert($msg) {
    include 'Extra/Key.php';
    $message = "gg.setVisible(true) gg.alert('" . addslashes($msg) . "', '')";
    $encryptedMessage = xorEncrypt($message, $key);
    exit($encryptedMessage);
}

function logSuccessfulLogin($key_value, $scriptToRun, $device_id) {
    $logFile = '#_Log.txt'; 
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // NOTE: Proxy check inside log function removed to avoid double API calls, 
    // relying on the main proxy check below.
    
    $logEntry = sprintf(
        "────────────────────────\n".
        "Timestamp : %s\n".
        "Device ID : %s\n".
        "IP : %s\n".
        "User-Agent : %s\n".
        "Script : %s\n".      "────────────────────────\n\n",
        date('Y-m-d H:i:s'),
        $device_id,
        $ip_address,
        $user_agent,
        $scriptToRun
    );
    $existingLogs = file_exists($logFile) ? file_get_contents($logFile) : '';
    // Optimized Regex for log replacement
    $existingLogs = preg_replace("/^────────────────────────\nTimestamp : [^\n]*\nDevice ID : " . preg_quote($device_id, '/') . "[^\n]*\n.*?────────────────────────\n\n/sm", '', $existingLogs);
    $updatedLogs = $existingLogs . $logEntry;
    file_put_contents($logFile, $updatedLogs);
}

// --- PROXY CHECK SYSTEM (KEPT FROM YOUR CODE) ---
$api_key = "a8318ebb828b842a852e442a07e8ad5b34525663f2996c6b877151e55a367101";
$ip_to_check = $_SERVER['REMOTE_ADDR'];

// Uncomment to enable live proxy check (May slow down script if API is slow)
/*
$url = "https://proxycheck.io/v2/$ip_to_check?key=$api_key&vpn=1&asn=1";
$response = file_get_contents($url);
$data = json_decode($response, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    exitAlert("┇ Failed To Parse API Response !");
}

$vpn = isset($data[$ip_to_check]['proxy']) && $data[$ip_to_check]['proxy'] === "yes";

if ($vpn) {
    exitAlert("┇ VPN Or Proxy Detected, Please Disable And Try Again !");
}
*/

$conn->begin_transaction();

try {

    $data_input = file_get_contents("php://input");

    if (empty($data_input)) {
        exitAlert("┇ No Data Received !");
    }

    $decodedData = xorEncrypt($data_input, $key);
    if ($decodedData === false) {
        exitAlert("┇ Data Decoding Failed !");
    }

    $key_input = $decodedData;

    // --- FETCH KEY DETAILS (ADDED duration_hours) ---
    $stmt_key = $conn->prepare("SELECT id, usage_limit, expiration_date, current_usage, status, duration_hours FROM api_keys WHERE key_value = ?");
    if (!$stmt_key) throw new Exception("Error preparing statement: " . $conn->error);
    $stmt_key->bind_param("s", $key_input);
    $stmt_key->execute();
    $result_key = $stmt_key->get_result();

    if ($result_key->num_rows === 1) {
        $key_data = $result_key->fetch_assoc();
        $key_id = $key_data['id'];
        $expiration_date = $key_data['expiration_date'];
        $usage_limit = $key_data['usage_limit'];
        $current_usage = $key_data['current_usage'];
        $status = $key_data['status'];
        $duration_hours = $key_data['duration_hours'];

        if ($status === 'revoked') {
            exitAlert("┇ Lock Temporarily Revoked By Publisher !");
        }       

        // --- NEW LOGIC: ACTIVATION ON FIRST USE ---
        if ($status === 'unused') {
            // Calculate Expiry Date based on Duration Hours
            $now = new DateTime();
            // Add hours to current time
            $now->modify("+{$duration_hours} hours");
            $new_expiry = $now->format('Y-m-d H:i:s');
            
            // Update Database to Active
            $stmt_activate = $conn->prepare("UPDATE api_keys SET status = 'active', expiration_date = ? WHERE id = ?");
            if (!$stmt_activate) throw new Exception("Error preparing activation: " . $conn->error);
            $stmt_activate->bind_param("si", $new_expiry, $key_id);
            $stmt_activate->execute();
            $stmt_activate->close();
            
            // Update local variables for this session
            $status = 'active';
            $expiration_date = $new_expiry;
        }
        // ------------------------------------------

        // Auto-fix if status is expired but date is extended manually
        if ($status === 'expired' && new DateTime() < new DateTime($expiration_date)) {
            $stmt_update_status = $conn->prepare("UPDATE api_keys SET status = 'active' WHERE id = ?");
            $stmt_update_status->bind_param("i", $key_id);
            $stmt_update_status->execute();
            $stmt_update_status->close();
            $status = 'active';
        }

        if ($status === 'active') {
            if (new DateTime() <= new DateTime($expiration_date)) {
                
                // --- YOUR DEVICE ID LOGIC (PRESERVED) ---
                $hash = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '', true);
                $device_id = base_convert(bin2hex($hash), 16, 10); 
                $device_id = substr($device_id, 0, 24);
                
                // Check Ban
                $stmt_ban_check = $conn->prepare("SELECT * FROM banned_devices WHERE device_id = ?");
                $stmt_ban_check->bind_param("s", $device_id);
                $stmt_ban_check->execute();
                $result_ban = $stmt_ban_check->get_result();

                if ($result_ban->num_rows > 0) {
                    exitAlert("┇ Your Device Has Been Banned !");
                } else {
                    // Check Device Link
                    $stmt_device_check = $conn->prepare("SELECT number_key_id FROM device_ids WHERE device_id = ? AND api_key_id = ?");
                    $stmt_device_check->bind_param("si", $device_id, $key_id);
                    $stmt_device_check->execute();
                    $result_device_check = $stmt_device_check->get_result();

                    if ($result_device_check->num_rows > 0) {
                        // Existing User
                        $device_data = $result_device_check->fetch_assoc();
                        $number_key_id = $device_data['number_key_id'];

                        if ($number_key_id > $usage_limit) {
                            exitAlert("┇ Max Device Limit Reached !");
                        }
                    } else {
                        // New User
                        $stmt_number_key_id = $conn->prepare("SELECT IFNULL(MAX(number_key_id), 0) + 1 AS next_key_id FROM device_ids WHERE api_key_id = ?");
                        $stmt_number_key_id->bind_param("i", $key_id);
                        $stmt_number_key_id->execute();
                        $result_number_key_id = $stmt_number_key_id->get_result();
                        $number_key_id = $result_number_key_id->fetch_assoc()['next_key_id'];

                        if ($number_key_id > $usage_limit) {
                            exitAlert("┇ Key Max Usage Reached !");
                        }

                        $stmt_insert = $conn->prepare("INSERT INTO device_ids (device_id, api_key_id, number_key_id) VALUES (?, ?, ?)");
                        $stmt_insert->bind_param("sii", $device_id, $key_id, $number_key_id);
                        $stmt_insert->execute();
                        $stmt_insert->close();
                    }

                    // Update Current Usage Counter
                    if ($number_key_id > $current_usage) {
                        $stmt_update_usage = $conn->prepare("UPDATE api_keys SET current_usage = ? WHERE id = ?");
                        $stmt_update_usage->bind_param("ii", $number_key_id, $key_id);
                        $stmt_update_usage->execute();
                        $stmt_update_usage->close();
                    }
                    
                    // Cleanup nulls (from your original code)
                    $conn->query("DELETE FROM device_ids WHERE api_key_id IS NULL");

                    $conn->commit();

                    // --- SCRIPT DELIVERY ---
                    if (strpos($key_input, 'FreeGame1-') === 0) $scriptToRun = $Free1;
                    elseif (strpos($key_input, 'FreeGame2-') === 0) $scriptToRun = $Free2;
                    elseif (strpos($key_input, 'FreeGame3-') === 0) $scriptToRun = $Free3;
                    elseif (strpos($key_input, 'Lite-') === 0) $scriptToRun = $Premium1;
                    elseif (strpos($key_input, 'Basic-') === 0) $scriptToRun = $Premium2;
                    elseif (strpos($key_input, 'Brutal-') === 0) $scriptToRun = $Premium3;
                    else exitAlert("┇ Invalid Key Format");

                    if (file_exists($scriptToRun)) {
                        logSuccessfulLogin($key_id, $scriptToRun, $device_id);
                        $scriptContent = file_get_contents($scriptToRun);
                        $EncryptScript = xorEncrypt($scriptContent, $key);
                        exit($EncryptScript);
                    } else {
                        exitAlert("┇ Script Not Found In Server");
                    }
                }
            } else {
                // Key Expired (Time check failed)
                $stmt_update_status = $conn->prepare("UPDATE api_keys SET status = 'expired' WHERE id = ?");
                $stmt_update_status->bind_param("i", $key_id);
                $stmt_update_status->execute();
                $stmt_update_status->close();
                $conn->commit();

                exitAlert("┇ Key Expired !");
            }
        } else {
            exitAlert("┇ Key Status: " . strtoupper($status));
        }
    } else {
        exitAlert("┇ Wrong Key !");
    }

    $stmt_key->close();
} catch (Exception $e) {
    $conn->rollback();
    exitAlert("┇ Error: " . $e->getMessage());
}

$conn->close();
?>