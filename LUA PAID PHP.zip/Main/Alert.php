<?php



error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(403);
    include 'Extra/403.html';
    exit();
}

date_default_timezone_set('Asia/Kolkata');

include 'Database.php';
include 'Extra/Key.php';

if ($conn === null) {
    die("Database connection failed.");
}

function xorEncrypt($data, $key) {
    $result = '';
    for ($i = 0; $i < strlen($data); $i++) {
        $result .= $data[$i] ^ $key[$i % strlen($key)];
    }
    return $result;
}

$data_input = file_get_contents("php://input");

$decodedData = xorEncrypt($data_input, $key);
if ($decodedData === false) {
    exit("┇ Data Decoding Failed");
}

$key_input = $decodedData;

if ($key_input) {
    // Fetched duration_hours and status
    $sql_key = "SELECT id, usage_limit, expiration_date, current_usage, key_value, status, duration_hours FROM api_keys WHERE key_value = ?";
    $stmt_key = $conn->prepare($sql_key);
    if (!$stmt_key) {
        die("Error preparing database statement: " . $conn->error);
    }

    $stmt_key->bind_param("s", $key_input);
    $stmt_key->execute();
    $result_key = $stmt_key->get_result();

    if ($result_key->num_rows === 1) {
        $key_data = $result_key->fetch_assoc();
        $key_id = $key_data['id'];
        $key_value = $key_data['key_value'];
        $expiration_date = $key_data['expiration_date'];
        $usage_limit = $key_data['usage_limit'];
        $current_usage = $key_data['current_usage'];
        $status = $key_data['status'];
        $duration = $key_data['duration_hours'];

        // Existing Logic to find Device ID linked to this key
        $sql_device_info = "SELECT device_id FROM device_ids WHERE api_key_id = ?";
        $stmt_device_info = $conn->prepare($sql_device_info);
        $stmt_device_info->bind_param("i", $key_id);
        $stmt_device_info->execute();
        $result_device_info = $stmt_device_info->get_result();

        $info = ''; 

        // Generate Info String
        $prefix = '';
        if (strpos($key_input, 'FreeGame1-') === 0) $prefix = ' Free Game 1';
        elseif (strpos($key_input, 'PremiumGame1-') === 0) $prefix = ' Premium Game 1';
        // (Add other prefixes as needed)
        if (!$prefix) $prefix = ' Custom Game';

        $info .= "© 2025 Powered By Ayu Live\n\n";
        $info .= "┇ Key Information\n\n";
        $info .= "Key: $key_value\n";
        $info .= "Game: $prefix\n";
        $info .= "Type: " . (strpos($key_input, 'Premium') === 0 ? 'Premium 💠' : 'Free 🌐') . "\n";

        // STATUS DISPLAY LOGIC
        if ($status === 'unused') {
            $days = $duration / 24;
            $info .= "Status: 🟡 UNUSED (Inactive)\n";
            $info .= "Duration: $days Days ($duration Hours)\n";
            $info .= "Validity: Will start on First Login\n";
        } elseif ($status === 'active') {
             // Check if actually expired by date
             if (strtotime($expiration_date) < time()) {
                $info .= "Status: 🔴 EXPIRED\n";
                $info .= "Expired On: " . date('d-M-Y H:i', strtotime($expiration_date)) . "\n";
             } else {
                $info .= "Status: 🟢 ACTIVE\n";
                $info .= "Expires: " . date('d-M-Y H:i', strtotime($expiration_date)) . "\n";
             }
        } elseif ($status === 'revoked') {
            $info .= "Status: 🚫 REVOKED (Banned)\n";
        } else {
            $info .= "Status: EXPIRED\n";
        }

        $info .= "Devices: $current_usage / $usage_limit 📱\n";

        // Show Device ID if found
        if ($result_device_info->num_rows > 0) {
            $device_row = $result_device_info->fetch_assoc();
            $info .= "\n┇ Your Device ID:\n" . $device_row['device_id'];
        }

        echo xorEncrypt($info, $key);

        $stmt_device_info->close();
    } else {
        echo xorEncrypt("┇ Key Not Found in Database\n", $key);
    }
    $stmt_key->close();
} else {
    echo xorEncrypt("┇ No Key Provided\n", $key);
}

$conn->close();
?>