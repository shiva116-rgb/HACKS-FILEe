<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Sheet</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="icon" href="Main/Extra/logo-table.svg" type="image/png">
    
    <style>
        html, body {
            height: 100%;
            margin: 0;
            font-family: 'Roboto', sans-serif;
        }
        body {
            background-color: #f8f9fa;
            padding-top: 20px;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container {
            flex: 1;
            margin-top: 20px;
            max-width: 1200px;
        }
        .table-container {
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            margin-bottom: 20px;
        }
        .header {
            color: #333;
            padding: 15px;
            border-radius: 10px;
            background-color: #e2f0e7;
            text-align: center;
            position: relative;
            display: flex;
            align-items: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            margin-bottom: 20px;
        }
        .header i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 24px;
            color: #333;
            padding: 10px;
            background: none;
        }
        .header h1 {
            margin: 0;
            padding-left: 50px;
            font-size: 1.5rem;
            font-weight: 700;
        }
        .table-responsive {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.875rem;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        th {
            background-color: #343a40;
            color: white;
            font-size: 0.875rem;
        }
        tbody tr:hover {
            background-color: #f1f1f1;
        }
        /* Status Badges */
        .badge-status { padding: 5px 10px; border-radius: 4px; font-weight: bold; color: white; display: inline-block; min-width: 80px; text-align: center; }
        .bg-active { background-color: #28a745; }
        .bg-unused { background-color: #ffc107; color: #000; }
        .bg-expired { background-color: #dc3545; }
        .bg-revoked { background-color: #6c757d; }
        
        .footer {
            color: #333333;
            text-align: center;
            padding: 20px;
            background-color: transparent;
            box-shadow: 0 -4px 8px rgba(0,0,0,0.2);
        }
        .footer p {
            margin: 0;
        }
        .back-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 12px 24px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1.1rem;
            font-weight: 700;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            transition: background-color 0.3s, transform 0.1s;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
        .back-button:active {
            transform: scale(0.95);
        }
    </style>
</head>
<body>

<div class="container">
    <div class="table-container">
        <div class="header">
            <i class="fas fa-key"></i>
            <h1>KEY LIST</h1>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Key</th>
                        <th>Duration / Expiry</th> <th>Usage Limit</th>
                        <th>Current Usage</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Connect Database 
                    include 'Database.php';

                    // Set charset for the connection
                    $conn->set_charset("utf8mb4");

                    // Query data from api_keys table (Added duration_hours and ORDER BY)
                    $sql = "SELECT id, key_value, expiration_date, duration_hours, usage_limit, current_usage, status FROM api_keys ORDER BY id DESC";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Display data row by row
                        while($row = $result->fetch_assoc()) {
                            $status = $row["status"];
                            $duration = $row["duration_hours"];
                            $expiry = $row["expiration_date"];
                            
                            // LOGIC: Show Duration if Unused, Date if Active/Expired
                            $timeDisplay = "";
                            $badgeClass = "";
                            
                            if ($status == 'unused') {
                                $days = $duration / 24;
                                $timeDisplay = $days . " Days (Waiting)";
                                $badgeClass = "bg-unused";
                            } elseif ($status == 'active') {
                                $timeDisplay = $expiry;
                                $badgeClass = "bg-active";
                            } elseif ($status == 'expired') {
                                $timeDisplay = $expiry . " (Ended)";
                                $badgeClass = "bg-expired";
                            } else {
                                $timeDisplay = "Locked";
                                $badgeClass = "bg-revoked";
                            }

                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . htmlspecialchars($row["key_value"]) . "</td>";
                            echo "<td>" . $timeDisplay . "</td>";
                            echo "<td>" . $row["usage_limit"] . "</td>";
                            echo "<td>" . $row["current_usage"] . "</td>";
                            echo "<td><span class='badge-status $badgeClass'>" . strtoupper($status) . "</span></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No results found.</td></tr>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="table-container">
        <div class="header">
            <i class="fas fa-ban"></i>
            <h1>BANNED DEVICES LIST</h1>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Device ID</th>
                        <th>Reason</th>
                        <th>Banned At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Reuse connection parameters from Database.php
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $conn->set_charset("utf8mb4");

                    $sql = "SELECT id, device_id, ban_reason, banned_at FROM banned_devices ORDER BY banned_at DESC";
                    $result = $conn->query($sql);

                    if ($result === FALSE) {
                        echo "Error: " . $conn->error;
                    } elseif ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row["id"] . "</td>";
                            echo "<td>" . $row["device_id"] . "</td>";
                            echo "<td>" . htmlspecialchars($row["ban_reason"]) . "</td>";
                            echo "<td>" . $row["banned_at"] . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4' class='text-center'>No results found.</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>

   <div class="table-container">
        <div class="header">
            <i class="fas fa-mobile-alt"></i>
            <h1>ID DEVICES LIST</h1>
        </div>

        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Device ID</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $conn->set_charset("utf8mb4");

                    // Getting Distinct Device IDs
                    $sql = "SELECT DISTINCT device_id FROM device_ids";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $id = 1;
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $id++ . "</td>";
                            echo "<td>" . $row["device_id"] . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='2' class='text-center'>No results found.</td></tr>";
                    }
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="footer">
        <p>&copy; Powered By Mars</p>
    </div>
</div>

<button class="back-button" onclick="goBack()">Back</button>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    function goBack() {
        window.location.href = 'Administrator';
    }
</script>

</body>
</html>