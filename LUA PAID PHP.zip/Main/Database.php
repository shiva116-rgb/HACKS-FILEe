<?php

$servername = "sql213.infinityfree.com";
$username = "if0_40682035";
$password = "shiva11699";
$dbname = "if0_40682035_free";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
                    }
?>
