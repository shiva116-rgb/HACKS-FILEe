<?php

$servername = "localhost";
$username = "wqtiaekt_ayulive";
$password = "Ayulive99@";
$dbname = "wqtiaekt_ayulive";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
                    }
?>
