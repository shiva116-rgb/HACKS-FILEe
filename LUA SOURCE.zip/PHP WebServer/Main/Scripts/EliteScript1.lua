

local targetInfo = gg.getTargetInfo()
local is32Bit = not targetInfo.x64

function mainMenu()
    local firstMenu = gg.choice(
        {"💀 One Hit 💀", "🎁 Free Shop 🎁", "❌ Thoát ❌"},
        nil,
        "Script By Hunter 👑\nGame: Pixel Fantasia x64 - x86\nPhiên Bản: 3.0.21\n━━━━━━━━━━━━━━━━━━━━━━━"
    )
    if firstMenu == 1 then
        cheat_2()
    elseif firstMenu == 2 then
        cheat_3()
    elseif firstMenu == 3 then
        exit()
    end
end

function applyValueFromClass(class, offset32, offset64, valueType, value, freeze)
    local offset = is32Bit and offset32 or offset64
    valueFromClass(class, offset, false, is32Bit, valueType)
    gg.getResults(9999)
    gg.editAll(value, valueType)
    if freeze then
        local results = gg.getResults(9999)
        for _, v in ipairs(results) do
            v.freeze = true
        end
        gg.addListItems(results)
    end
    gg.clearResults()
end

function cheat_1()
    applyValueFromClass("PlayerController", "0xD8", "0x170", gg.TYPE_DWORD, 99999, false)
    applyValueFromClass("PlayerController", "0x44", "0x6C", gg.TYPE_FLOAT, 1, true)
    applyValueFromClass("PlayerController", "0x70", "0x70", gg.TYPE_FLOAT, 9999999, true)
    gg.toast("Đã bật One Hit")
end

function cheat_2()
    applyValueFromClass("G_CharacterStatus", "0xC0", "0x170", gg.TYPE_DOUBLE, 9999999999999999999, true)
    gg.toast("Kích hoạt One Hit")
end

function cheat_3()
    applyValueFromClass("G_ShopProductData", "0x40", "0x54", gg.TYPE_DWORD, 1, false)
    applyValueFromClass("G_ShopProductData", "0x44", "0x58", gg.TYPE_DWORD, 1, false)
    applyValueFromClass("G_ShopProductData", "0x50", "0x6C", gg.TYPE_DWORD, 999, false)
    gg.toast("Kích hoạt Free Shop")
    stopClose()
end

function exit()
    gg.clearResults()
    gg.clearList()
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("     亗 ＳＣＲＩＰＴㅤＢＹㅤＨＵＮＴＥＲ   모")
    print("     👑 t.me/hunteroct 👑")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    gg.setVisible(true)
    os.exit()
end

function valueFromClass(class, offset, tryHard, bit32, valueType)
    Get_user_input = {class, offset, tryHard, bit32}
    Get_user_type = valueType
    start()
end

function O_initial_search()
    gg.setVisible(false)
    user_input = ":" .. Get_user_input[1]
    offst = Get_user_input[3] and 25 or 0
end

function O_dinitial_search()
    gg.setRanges(gg.REGION_OTHER)
    gg.searchNumber(user_input, gg.TYPE_BYTE)
    local count = gg.getResultsCount()
    if count == 0 then return 0 end
    local Refiner = gg.getResults(1)
    gg.refineNumber(Refiner[1].value, gg.TYPE_BYTE)
    count = gg.getResultsCount()
    if count == 0 then return 0 end
    local val = gg.getResults(count)
    gg.addListItems(val)
end

function CA_pointer_search()
    gg.clearResults()
    gg.setRanges(gg.REGION_C_ALLOC | gg.REGION_OTHER)
    gg.loadResults(gg.getListItems())
    gg.searchPointer(offst)
    local count = gg.getResultsCount()
    if count == 0 then return 0 end
    local vel = gg.getResults(count)
    gg.clearList()
    gg.addListItems(vel)
end

function CA_apply_offset()
    local tanker = Get_user_input[4] and 0xfffffffffffffff8 or 0xfffffffffffffff0
    local l = gg.getListItems()
    gg.removeListItems(l)
    for _, v in ipairs(l) do
        v.address = v.address + tanker
    end
    gg.addListItems(l)
end

function Q_apply_fix()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.loadResults(gg.getListItems())
    gg.clearList()
    local count = gg.getResultsCount()
    if count == 0 then return 0 end
    local yy = gg.getResults(1000)
    gg.clearResults()
    local s = {}
    for i = 1, count do
        yy[i].address = yy[i].address + 0xb400000000000000
        gg.searchNumber(yy[i].address, gg.TYPE_QWORD)
        local cnt = gg.getResultsCount()
        if cnt > 0 then
            local bytr = gg.getResults(cnt)
            for n = 1, cnt do
                s[#s + 1] = {address = bytr[n].address, flags = 32}
            end
        end
        gg.clearResults()
    end
    gg.addListItems(s)
end

function A_base_value()
    gg.setRanges(gg.REGION_ANONYMOUS)
    gg.loadResults(gg.getListItems())
    gg.clearList()
    gg.searchPointer(offst)
    local count = gg.getResultsCount()
    if count == 0 then return 0 end
    local tel = gg.getResults(count)
    gg.addListItems(tel)
end

function A_base_accuracy()
    gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_C_ALLOC)
    gg.loadResults(gg.getListItems())
    gg.clearList()
    gg.searchPointer(offst)
    local count = gg.getResultsCount()
    if count == 0 then return 0 end
    local kol = gg.getResults(count)
    local h = {}
    for i = 1, count do
        h[i] = {address = kol[i].value, flags = 32}
    end
    gg.addListItems(h)
end

function A_user_given_offset()
    local old_save_list = gg.getListItems()
    for _, v in ipairs(old_save_list) do
        v.address = v.address + Get_user_input[2]
        v.flags = Get_user_type
    end
    gg.clearResults()
    gg.clearList()
    gg.loadResults(old_save_list)
    if gg.getResultsCount() == 0 then return 0 end
    gg.setVisible(false)
end

function start()
    O_initial_search()
    O_dinitial_search()
    CA_pointer_search()
    CA_apply_offset()
    A_base_value()
    if offst == 0 then
        A_base_accuracy()
    end
    A_user_given_offset()
end

function UI()
    gg.showUiButton()
    while true do
        if gg.isClickedUiButton() then
            start()
        end
    end
end

function stopClose()
    gg.setVisible(true)
    while true do
        if gg.isVisible() then
            gg.setVisible(false)
            mainMenu()
        end
    end
end

stopClose()