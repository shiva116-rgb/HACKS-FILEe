gg.alert("⚡ WELCOME TO BIHARI MODZ PLUS ⚡")
function script()
menuprincipal = gg.choice({
'➡️  🔴LOCATION MENU🔴',
'➡️  🟣SNIPER MENU🟣',
'➡️  🟣EXTRA🟣',
'🔙EXIT🔙',
},nil,'🛑TEAM BIHARI OB50 PREMIUM PANEL🛑[OWNER BY TEAM BIHARI🎭]')
if menuprincipal == nil then gg.toast('⚡BIHARI MODZ PLUS⚡') else
if menuprincipal == 1 then menugps() end
if menuprincipal == 2 then menuarmas() end
if menuprincipal == 3 then menuarmas1() end
if menuprincipal == 4 then gg.setVisible(true) os.exit(print(' 🔴OWNER - 🎭TEAM BIHARI🎭--------------ENJOY YOUR GAME AND SUPPORT BIHARI TEAM🔴')) end
end end
function menugps()
gps = gg.multiChoice({
'🔴ANTENNA LOCATION (HEAD)🔴',
'🔴ANTENNA LOCATION (HAND)🔴',
'🔙BACK🔙'
},nil,'🔵LOCATION MENU🔵')
if gps == nil then gg.toast('⚡BIHARI MODZ PLUS⚡') else
if gps [1] then gpscabeza() end
if gps [2] then gpscuello() end
if gps [3] then gg.setVisible(true) end
end end
function gpscabeza()
gg.setRanges(gg.REGION_ANONYMOUS)
  gg.searchNumber("-0.30576485395;0.01430506539;-0.73534429073;1::13", gg.TYPE_FLOAT)
  gg.refineNumber("1", gg.TYPE_FLOAT)
  gg.getResults(gg.getResultsCount())
  gg.editAll("3000", gg.TYPE_FLOAT)
  gg.clearResults()
  gg.searchNumber("-0.2212036103;0.03038031235;-0.76885718107;1::13", gg.TYPE_FLOAT)
  gg.refineNumber("1", gg.TYPE_FLOAT)
  gg.getResults(gg.getResultsCount())
  gg.editAll("3000", gg.TYPE_FLOAT)
  gg.clearResults()
  gg.toast("📡 Head Antenna On")
end

function gpscuello()
gg.setRanges(gg.REGION_ANONYMOUS)
    gg.searchNumber('-0.02980032004;1;0.48141112924::9', gg.TYPE_FLOAT)
    gg.refineNumber('1', gg.TYPE_FLOAT)
    gg.getResults(gg.getResultsCount())
    gg.editAll('3000', gg.TYPE_FLOAT)
    gg.clearResults()

    gg.searchNumber('0.09043131769;1;0.14753369987::9', gg.TYPE_FLOAT)
    gg.refineNumber('1', gg.TYPE_FLOAT)
    gg.getResults(gg.getResultsCount())
    gg.editAll('3000', gg.TYPE_FLOAT)
    gg.clearResults()

    gg.toast('📡 Antena Hand ON')

function menuarmas()
armas = gg.multiChoice({
'🔴ALL SNIPER AIMBOT🔴 ',
'🔴SNIPER FAST SWITCH🔴',
'🔴SNIPER AIM 🔴',
'🔴SPEED TIMER🔴',
'🔙BACK🔙'
},nil,'🔵SNIPER MENU🔵')
if armas == nil then gg.toast('⚡BIHARI MODZ PLUS⚡') else
if armas [1] then balasrectas() end
if armas [2] then tiroalacabeza55() end
if armas [3] then delayfix() end
if armas [4] then speed() end
if armas [5] then gg.setVisible(true) end
end end
function balasrectas()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.setVisible(false)
gg.searchNumber("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 80 3F 33 33 13 40 00 00 B0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
gg.getResults(1500.0)
gg.editAll("h08 00 00 00 00 00 60 40 CD CC 8C 3F 8F C2 F5 3C CD CC CC 3D 06 00 00 00 00 00 80 3f 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 33 33 13 40 00 00 B0 3F 00 00 80 3F 01", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER AIMBOT ON ✅")
end
function tiroalacabeza55()
  gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
  gg.searchNumber("h 00 00 00 00 3f 00 00 80 3e", gg.TYPE_BYTE)
  gg.getResults(1000, nil, nil)
  gg.editAll("h 00 ec 51 b8 3d 8f c2 f5 3c", gg.TYPE_BYTE)
  gg.clearResults()
  gg.searchNumber("h9A 99 19 3F 00 00 80 3E 00 00 00 00 04", gg.TYPE_BYTE)
  gg.getResults(1000, nil, nil)
  gg.editAll("hEC 51 B8 3D 8F C2 F5 3C 00 00 00 00 04", gg.TYPE_BYTE)
  gg.clearResults()
  gg.toast("Fast Switch On")
end
function delayfix()
gg.setRanges(gg.REGION_ANONYMOUS | gg.REGION_CODE_APP)
gg.searchNumber("h 01 00 00 00 00 00 00 00 00 00 00 00 41 00 00 00 00 00 00 00 01 00 00 00 CD CC", gg.TYPE_BYTE, false, gg.SIGN_EQUAL, 0, -1, 0)
gg.getResults(5500, 0, 0, -1, nil, nil, 0, nil, 0)
gg.editAll("h 01 00 00 00 00 00 00 00 00 00 00 00 41 00 00 00 00 00 00 00 00 00 00 00 CD CC", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("SNIPER AIM 🚀")
end

function menuarmas1()
armas1 = gg.multiChoice({
'🔴ALL SNIPER AIMBOT🔴 ',
'🔴SNIPER FAST SWITCH🔴',
'🔴SNIPER AIM 🔴',
'🔴SPEED TIMER🔴',
'🔙BACK🔙'
},nil,'🔵SNIPER MENU🔵')
if armas1 == nil then gg.toast('⚡BIHARI MODZ PLUS⚡') else
if armas1 [1] then speed() end
if armas1 [2] then wall1() end
if armas1 [3] then wall2() end
if armas1 [4] then norec() end
if armas1 [5] then gg.setVisible(true) end
end end

function speed()
  gg.setRanges(gg.REGION_C_ALLOC)

  -- Modified full pattern (12 bytes)
  gg.searchNumber("h02 2B 99 3C 02 2B 99 3C 02 2B 99 3C", gg.TYPE_BYTE)
  if gg.getResultsCount() > 0 then
    -- Already ON → turn OFF
    gg.getResults(100)
    gg.editAll("h02 2B 07 3D 02 2B 07 3D 02 2B 07 3D", gg.TYPE_BYTE)
    gg.clearResults()
    gg.toast("❄️ Speed OFF ❌")
  else
    -- OFF → turn ON
    gg.searchNumber("h02 2B 07 3D 02 2B 07 3D 02 2B 07 3D", gg.TYPE_BYTE)
    gg.getResults(100)
    gg.editAll("h02 2B 99 3C 02 2B 99 3C 02 2B 99 3C", gg.TYPE_BYTE)
    gg.clearResults()
    gg.toast("🔥 Speed ON ✅")
  end
function wall1()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.setVisible(false)
gg.searchNumber("h3F AE 47 81 3F 00 1A B7 EE DC 3A 9F ED 30", gg.TYPE_BYTE)
gg.getResults(1500.0)
gg.editAll("hBF AE 47 81 3F 00 1A B7 EE DC 3A 9F ED 30", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("WALL HACK ON ✅")
end
function wall2()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.setVisible(false)
gg.searchNumber("hBF AE 47 81 3F 00 1A B7 EE DC 3A 9F ED 30", gg.TYPE_BYTE)
gg.getResults(1500.0)
gg.editAll("h3F AE 47 81 3F 00 1A B7 EE DC 3A 9F ED 30", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("WALL HACK OFF ❌")
end
function norec()
gg.setRanges(gg.REGION_ANONYMOUS)
gg.setVisible(false)
gg.searchNumber("hBF AE 47 81 3F 00 1A B7 EE DC 3A 9F ED 30", gg.TYPE_BYTE)
gg.getResults(1500.0)
gg.editAll("h3F AE 47 81 3F 00 1A B7 EE DC 3A 9F ED 30", gg.TYPE_BYTE)
gg.clearResults()
gg.toast("No Recoil On 🔥")
end
while true do if gg.isVisible() then gg.setVisible(false) script() end end